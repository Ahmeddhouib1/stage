import React, { useState } from 'react';
import UploadFeatureFile from './components/UploadFeatureFile';

export default function App() {
  const [result, setResult] = useState(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-400 via-purple-400 to-pink-400 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animation de bulles */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="absolute w-72 h-72 bg-white opacity-10 rounded-full -top-10 -left-10 animate-pulse"></div>
        <div className="absolute w-72 h-72 bg-white opacity-10 rounded-full bottom-0 right-0 animate-ping"></div>
      </div>

      <div className="relative z-10 bg-white bg-opacity-90 backdrop-blur-md rounded-3xl shadow-2xl p-10 max-w-xl w-full">
        <h1 className="text-4xl font-bold text-center text-indigo-700 mb-4">✅ TestFlow Validator</h1>
        <p className="text-center text-gray-600 mb-8">
          Analyse intelligente de vos fichiers <code>.feature</code>
        </p>

        <UploadFeatureFile onResult={setResult} />

        {result && (
          <div className="mt-8 p-4 bg-green-50 text-gray-800 rounded-md border border-green-200 overflow-auto max-h-96">
            <h2 className="text-lg font-semibold mb-2">Résultat :</h2>
            <pre className="whitespace-pre-wrap text-sm">{JSON.stringify(result, null, 2)}</pre>
          </div>
        )}
      </div>
    </div>
  );
}
